package hu.bme.aut.android.jot.fragments.add

import android.app.AlertDialog
import android.os.Bundle
import android.text.Editable
import android.text.TextUtils
import android.view.*
import androidx.fragment.app.Fragment
import android.widget.Toast
import androidx.lifecycle.ViewModelProvider
import androidx.navigation.findNavController
import androidx.navigation.fragment.navArgs
import hu.bme.aut.android.jot.MainActivity
import hu.bme.aut.android.jot.R
import hu.bme.aut.android.jot.data.task.TaskItem
import hu.bme.aut.android.jot.data.task.TaskViewModel
import hu.bme.aut.android.jot.databinding.FragmentEditTaskBinding

class editTaskFragment : Fragment() {

    private val args by navArgs<editTaskFragmentArgs>()
    private lateinit var binding: FragmentEditTaskBinding
    private lateinit var viewmodel: TaskViewModel

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        // Inflate the layout for this fragment
        viewmodel = ViewModelProvider(this).get(TaskViewModel::class.java)


        binding = FragmentEditTaskBinding.inflate(inflater,container, false)
        (activity as MainActivity?)?.setActionBarTitle(getString(R.string.str))
        binding.editname.setText(args.task.name)
        binding.eweight.setText(args.task.weight.toString())
        binding.egainedWeight.setText(args.task.gainedweight.toString())
        binding.edittaskbutton.setOnClickListener {
            updateItem(args.task)
        }

        setHasOptionsMenu(true)
        return binding.root
    }

    private fun updateItem(task: TaskItem) {
        val name = binding.editname.text.toString()

        if (inputCheck(name,binding.eweight.text,binding.egainedWeight.text)) {
            val weight = (binding.eweight.text.toString()).toDouble()
            val gained = (binding.egainedWeight.text.toString()).toDouble()
            // Create User Object
            val updatedTask = TaskItem(args.task.id,args.task.excercisename, name, weight, gained)
            // Update Current User
            viewmodel.updateTask(updatedTask)
            Toast.makeText(requireContext(), "Updated Successfully!", Toast.LENGTH_SHORT).show()
            // Navigate
            val action = editTaskFragmentDirections.actionEditTaskFragmentToExcerciseFragment(args.excercise)
            binding.root.findNavController().navigate(action)
        } else {
            Toast.makeText(requireContext(), "Please fill out all fields.", Toast.LENGTH_SHORT)
                .show()
        }
    }

    private fun inputCheck(firstName: String, weight: Editable, gweight: Editable): Boolean{
        return !(TextUtils.isEmpty(firstName) && weight.isEmpty() && gweight.isEmpty())
    }
    override fun onCreateOptionsMenu(menu: Menu, inflater: MenuInflater) {
        inflater.inflate(R.menu.delete_menu, menu)
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        if (item.itemId == R.id.menu_delete) {
            deleteTask()
        }
        return super.onOptionsItemSelected(item)
    }

    private fun deleteTask() {
        val builder = AlertDialog.Builder(requireContext())
        builder.setPositiveButton("Yes") { _, _ ->
            viewmodel.deleteTask(args.task)
            Toast.makeText(
                requireContext(),
                "Successfully removed: ${args.task.name}",
                Toast.LENGTH_SHORT).show()
            val action = editTaskFragmentDirections.actionEditTaskFragmentToExcerciseFragment(args.excercise)
            binding.root.findNavController().navigate(action)
        }
        builder.setNegativeButton("No") { _, _ -> }
        builder.setTitle("Delete ${args.task.name}?")
        builder.setMessage("Are you sure you want to delete ${args.task.name}?")
        builder.create().show()
    }

}