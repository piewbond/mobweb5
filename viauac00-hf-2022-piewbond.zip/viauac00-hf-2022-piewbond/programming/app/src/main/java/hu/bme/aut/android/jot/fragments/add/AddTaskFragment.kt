package hu.bme.aut.android.jot.fragments.add

import android.os.Bundle
import android.text.Editable
import android.text.TextUtils
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Toast
import androidx.lifecycle.ViewModelProvider
import androidx.navigation.findNavController
import androidx.navigation.fragment.navArgs
import hu.bme.aut.android.jot.MainActivity
import hu.bme.aut.android.jot.R
import hu.bme.aut.android.jot.data.task.TaskItem
import hu.bme.aut.android.jot.data.task.TaskViewModel
import hu.bme.aut.android.jot.databinding.FragmentAddTaskBinding


class AddTaskFragment : Fragment() {

    private val args by navArgs<AddTaskFragmentArgs>()
    private lateinit var mUserViewModel: TaskViewModel
    private lateinit var binding: FragmentAddTaskBinding
    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        // Inflate the layout for this fragment
        mUserViewModel = ViewModelProvider(this).get(TaskViewModel::class.java)
        binding = FragmentAddTaskBinding.inflate(inflater, container, false)
        (activity as MainActivity?)?.setActionBarTitle(getString(R.string.addtaskna))
        binding.addtaskbutton.setOnClickListener {
            insertDataToDatabase()
        }
        return binding.root
    }

    private fun insertDataToDatabase() {
        val firstName = binding.editTaskName.text.toString()

        if(inputCheck(firstName,binding.editWeight.text,binding.editgainedWeight.text)){
            val weight =   binding.editWeight.text.toString().toDouble()
            val gainedweight = binding.editgainedWeight.text.toString().toDouble()
            // Create User Object
            val item = TaskItem(
                null,
                args.excerciseItem.name.toString(),
                firstName,
                weight,
                gainedweight
            )
//            // Add Data to Database
            mUserViewModel.addTask(item)
            Toast.makeText(requireContext(), "Successfully added!", Toast.LENGTH_LONG).show()
            // Navigate Back
            val action = AddTaskFragmentDirections.actionAddTaskFragmentToExcerciseFragment(args.excerciseItem)
            binding.root.findNavController().navigate(action)
        }else{
            Toast.makeText(requireContext(), "Please fill out the field", Toast.LENGTH_LONG).show()
        }
    }
    private fun inputCheck(firstName: String, weight: Editable, gweight: Editable): Boolean{
        return !(TextUtils.isEmpty(firstName) && weight.isEmpty() && gweight.isEmpty())
    }
}