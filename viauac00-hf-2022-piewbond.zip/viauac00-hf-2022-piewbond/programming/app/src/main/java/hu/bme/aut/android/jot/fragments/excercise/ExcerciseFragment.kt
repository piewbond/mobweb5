package hu.bme.aut.android.jot.fragments.excercise

import android.app.AlertDialog
import android.os.Bundle
import android.view.*
import android.widget.Toast
import androidx.fragment.app.Fragment
import androidx.lifecycle.Observer
import androidx.lifecycle.ViewModelProvider
import androidx.navigation.findNavController
import androidx.navigation.fragment.findNavController
import androidx.navigation.fragment.navArgs
import androidx.recyclerview.widget.LinearLayoutManager
import hu.bme.aut.android.jot.MainActivity
import hu.bme.aut.android.jot.R
import hu.bme.aut.android.jot.data.ExcerciseViewModel
import hu.bme.aut.android.jot.data.task.TaskViewModel
import hu.bme.aut.android.jot.databinding.FragmentExcerciseBinding

class ExcerciseFragment : Fragment() {
    private lateinit var binding: FragmentExcerciseBinding
    private lateinit var mUserViewModel: ExcerciseViewModel
    private lateinit var viewmodel: TaskViewModel
    private val args by navArgs<ExcerciseFragmentArgs>()

    private lateinit var adapter: TaskAdapter

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        // Inflate the layout for this fragment
        binding = FragmentExcerciseBinding.inflate(inflater,container, false)
        setHasOptionsMenu(true)
        (activity as MainActivity?)?.setActionBarTitle(args.excercise.name.toString())

        adapter = TaskAdapter()
        adapter.excerciseItem = args.excercise
        val recyclerView = binding.taskrecyclerview
        recyclerView.adapter = adapter
        recyclerView.layoutManager = LinearLayoutManager(requireContext())


        viewmodel = ViewModelProvider(this).get(TaskViewModel::class.java)
        viewmodel.readAllData.observe(viewLifecycleOwner, Observer { user ->
            adapter.setData(user)
        })


        binding.taskActionButton.setOnClickListener {
            val action = ExcerciseFragmentDirections.actionExcerciseFragmentToAddTaskFragment(args.excercise)
            binding.root.findNavController().navigate(action)
        }

        return binding.root
    }

    override fun onCreateOptionsMenu(menu: Menu, inflater: MenuInflater) {
        inflater.inflate(R.menu.delete_menu,menu)
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        if (item.itemId == R.id.menu_delete)
            deleteExcercise()
        if (item.itemId == R.id.save_menu)
            saveTasks()

        return super.onOptionsItemSelected(item)
    }

    private fun saveTasks() {
        viewmodel = ViewModelProvider(this).get(TaskViewModel::class.java)
        adapter.getData().forEach{
            viewmodel.updateTask(it)
        }
    }

    private fun deleteExcercise() {
        mUserViewModel = ViewModelProvider(this).get(ExcerciseViewModel::class.java)
        val builder = AlertDialog.Builder(requireContext())
        builder.setPositiveButton(getString(R.string.y)) { _, _ ->
            mUserViewModel.deleteExcercise(args.excercise)
            Toast.makeText(
                requireContext(),
                "Successfully removed: ${args.excercise.name}",
                Toast.LENGTH_SHORT).show()
            findNavController().navigate(R.id.listFragment)
        }
        builder.setNegativeButton("No") { _, _ -> }
        builder.setTitle("Delete ${args.excercise.name}?")
        builder.setMessage("Are you sure you want to delete ${args.excercise.name}?")
        builder.create().show()
    }
}