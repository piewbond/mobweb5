package hu.bme.aut.android.jot.fragments.list

import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.lifecycle.Observer
import androidx.lifecycle.ViewModelProvider
import androidx.navigation.fragment.findNavController
import androidx.recyclerview.widget.LinearLayoutManager
import hu.bme.aut.android.jot.MainActivity
import hu.bme.aut.android.jot.R
import hu.bme.aut.android.jot.data.ExcerciseItem
import hu.bme.aut.android.jot.data.ExcerciseViewModel
import hu.bme.aut.android.jot.databinding.FragmentListBinding

class ListFragment : Fragment() {
    private lateinit var binding : FragmentListBinding

    private lateinit var viewmodel: ExcerciseViewModel

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        binding = FragmentListBinding.inflate(inflater, container, false)
        (activity as MainActivity?)?.setActionBarTitle(getString(R.string.excercisetab))
        // Recyclerview
        val adapter = ListAdapter()
        val recyclerView = binding.recyclerview
        recyclerView.adapter = adapter
        recyclerView.layoutManager = LinearLayoutManager(requireContext())


        viewmodel = ViewModelProvider(this).get(ExcerciseViewModel::class.java)
        viewmodel.readAllData.observe(viewLifecycleOwner, Observer { user ->
            adapter.setData(user)
        })
        binding.floatingActionButton.setOnClickListener {
            findNavController().navigate(R.id.addFragment)
        }

        // Add menu
        setHasOptionsMenu(true)

        return binding.root
    }

}