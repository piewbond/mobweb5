package hu.bme.aut.android.jot

import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import androidx.navigation.findNavController

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        supportActionBar?.setDisplayHomeAsUpEnabled(true)
    }

    override fun onSupportNavigateUp(): Boolean {
        val navController =findNavController(R.id.fragment)
        return navController.navigateUp() || super.onSupportNavigateUp()
    }
    fun setActionBarTitle(title: String?) {
        supportActionBar?.title = title
    }
}