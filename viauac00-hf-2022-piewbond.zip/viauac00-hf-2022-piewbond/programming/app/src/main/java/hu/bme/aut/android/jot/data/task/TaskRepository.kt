package hu.bme.aut.android.jot.data.task

import androidx.lifecycle.LiveData

class TaskRepository (private val excerciseDao: TaskItemDao){
    val readAllData: LiveData<List<TaskItem>> = excerciseDao.getAll()

    suspend fun addTask(excercise: TaskItem){
        excerciseDao.insert(excercise)
    }

    suspend fun updateTask(excercise: TaskItem){
        excerciseDao.update(excercise)
    }

    suspend fun deleteTask(excercise: TaskItem){
        excerciseDao.deleteExcerciseItem(excercise)
    }

    suspend fun deleteAll(){
        excerciseDao.nukeTable()
    }
}