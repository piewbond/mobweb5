package hu.bme.aut.android.jot.data


import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.LiveData
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

class ExcerciseViewModel(application: Application): AndroidViewModel(application) {
    val readAllData: LiveData<List<ExcerciseItem>>
    private val repository: ExcerciseRepository

    init {
        val userDao = ExcerciseDatabase.getDatabase(
            application
        ).exerciseItemDao()
        repository = ExcerciseRepository(userDao)
        readAllData = repository.readAllData
    }

    fun addExcercise(excercise: ExcerciseItem){
        viewModelScope.launch(Dispatchers.IO) {
            repository.addExcercise(excercise)
        }
    }

    fun updateExcercise(excercise: ExcerciseItem){
        viewModelScope.launch(Dispatchers.IO) {
            repository.updateExcercise(excercise)
        }
    }

    fun deleteExcercise(excercise: ExcerciseItem){
        viewModelScope.launch(Dispatchers.IO) {
            repository.deleteExcercise(excercise)
        }
    }

    fun findExcercise(pos: Int) : ExcerciseItem? {
        return readAllData.value?.get(pos)
    }

//    fun deleteAllExcercises(){
//        viewModelScope.launch(Dispatchers.IO) {
//            repository.deleteAllExcercises()
//        }
//    }
}