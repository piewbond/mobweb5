package hu.bme.aut.android.jot.fragments.excercise

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.navigation.findNavController
import androidx.recyclerview.widget.RecyclerView
import hu.bme.aut.android.jot.data.ExcerciseItem
import hu.bme.aut.android.jot.data.task.TaskItem
import hu.bme.aut.android.jot.databinding.TaskitemBinding

class TaskAdapter : RecyclerView.Adapter<TaskAdapter.MyViewHolder>(){
    private var userList = emptyList<TaskItem>()
    lateinit var excerciseItem: ExcerciseItem

    class MyViewHolder(val binding: TaskitemBinding): RecyclerView.ViewHolder(binding.root) {}

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int)=  MyViewHolder (

        TaskitemBinding.inflate(LayoutInflater.from(parent.context), parent, false)

    )

    override fun getItemCount(): Int {
        return userList.size
    }

    override fun onBindViewHolder(holder: MyViewHolder, position: Int) {
        val item = userList[position]
            holder.binding.taskName.text = item.name.toString()
            holder.binding.taskweight.text = item.weight.toString()
            holder.binding.gains.text = "Total gains:" + item.gainedweight.toString()
            holder.binding.ibedit.setOnClickListener {
                val action = ExcerciseFragmentDirections.actionExcerciseFragmentToEditTaskFragment(item,excerciseItem)
                holder.binding.root.findNavController().navigate(action)
            }
            holder.binding.minusbutton.setOnClickListener {
                userList[position].weight -= 0.5
                userList[position].gainedweight -= 0.5
                holder.binding.taskweight.text = (holder.binding.taskweight.text.toString().toDouble()-0.5).toString()
                holder.binding.gains.text = "Total gains:" + userList[position].gainedweight.toString()
            }
            holder.binding.plusbutton.setOnClickListener {
                userList[position].weight += 0.5
                userList[position].gainedweight += 0.5
                holder.binding.taskweight.text = (holder.binding.taskweight.text.toString().toDouble()+0.5).toString()
                holder.binding.gains.text = "Total gains:" + userList[position].gainedweight.toString()
            }
        if (excerciseItem.name.toString() == item.excercisename)
            holder.itemView.visibility = View.VISIBLE
        else
        {
            holder.itemView.visibility = View.GONE
            holder.itemView.layoutParams = RecyclerView.LayoutParams(0, 0)
        }
    }

    fun setData(user: List<TaskItem>){
        userList = user
        notifyDataSetChanged()
    }

    fun getData(): List<TaskItem> {
        return userList
    }
}