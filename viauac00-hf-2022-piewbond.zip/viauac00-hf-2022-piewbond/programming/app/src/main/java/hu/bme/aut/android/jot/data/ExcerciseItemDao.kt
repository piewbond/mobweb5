package hu.bme.aut.android.jot.data

import androidx.lifecycle.LiveData
import androidx.room.*

@Dao
interface ExcerciseItemDao {

    @Query("SELECT * FROM excerciseitem ORDER BY id ASC")
    fun getAll(): LiveData<List<ExcerciseItem>>

    @Insert
    fun insert(excerciseItem: ExcerciseItem): Long

    @Update
    fun update(excerciseItem: ExcerciseItem)

    @Delete
    fun deleteExcerciseItem(excerciseItem: ExcerciseItem)

//    @Query("DELETE FROM excerciseitem")
//    suspend fun deleteAll()

}