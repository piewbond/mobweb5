package hu.bme.aut.android.jot.data.task

import androidx.lifecycle.LiveData
import androidx.room.*

@Dao
interface TaskItemDao {

    @Query("SELECT * FROM taskitem ORDER BY id ASC")
    fun getAll(): LiveData<List<TaskItem>>

    @Insert
    fun insert(excerciseItem: TaskItem): Long

    @Update
    fun update(excerciseItem: TaskItem)

    @Delete
    fun deleteExcerciseItem(excerciseItem: TaskItem)

    @Query("DELETE FROM taskitem")
    fun nukeTable()

}