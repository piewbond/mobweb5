package hu.bme.aut.android.jot.data.task

import android.os.Parcelable
import androidx.room.ColumnInfo
import androidx.room.Entity
import androidx.room.PrimaryKey
import kotlinx.android.parcel.Parcelize

@Parcelize
@Entity(tableName = "taskitem")
data class TaskItem (
    @ColumnInfo(name = "id") @PrimaryKey(autoGenerate = true) var id: Long? = null,
    @ColumnInfo(name = "excercisename") var excercisename: String,
    @ColumnInfo(name = "taskname") var name: String,
    @ColumnInfo(name = "weight") var weight: Double,
    @ColumnInfo(name = "gainedweight") var gainedweight: Double
//    @ColumnInfo(name = "Excercise") var excercise: ExcerciseItem
) : Parcelable
