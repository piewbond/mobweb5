package hu.bme.aut.android.jot.data.task


import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.LiveData
import androidx.lifecycle.viewModelScope
import hu.bme.aut.android.jot.data.task.TaskItemDatabase
import hu.bme.aut.android.jot.data.task.TaskItem
import hu.bme.aut.android.jot.data.task.TaskRepository
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

class TaskViewModel(application: Application): AndroidViewModel(application) {
    val readAllData: LiveData<List<TaskItem>>
    private val repository: TaskRepository

    init {
        val userDao = TaskItemDatabase.getDatabase(
            application
        ).taskItemDao()
        repository = TaskRepository(userDao)
        readAllData = repository.readAllData
    }

    fun addTask(excercise: TaskItem){
        viewModelScope.launch(Dispatchers.IO) {
            repository.addTask(excercise)
        }
    }

    fun updateTask(excercise: TaskItem){
        viewModelScope.launch(Dispatchers.IO) {
            repository.updateTask(excercise)
        }
    }

    fun deleteTask(excercise: TaskItem){
        viewModelScope.launch(Dispatchers.IO) {
            repository.deleteTask(excercise)
        }
    }

    fun findTask(pos: Int) : TaskItem? {
        return readAllData.value?.get(pos)
    }

    fun deleteAllTask(){
        viewModelScope.launch(Dispatchers.IO) {
            repository.deleteAll()
        }
    }
}