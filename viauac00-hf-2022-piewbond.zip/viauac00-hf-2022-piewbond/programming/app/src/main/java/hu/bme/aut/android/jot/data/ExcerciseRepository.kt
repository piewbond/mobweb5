package hu.bme.aut.android.jot.data

import androidx.lifecycle.LiveData

class ExcerciseRepository (private val excerciseDao: ExcerciseItemDao){
    val readAllData: LiveData<List<ExcerciseItem>> = excerciseDao.getAll()

    suspend fun addExcercise(excercise: ExcerciseItem){
        excerciseDao.insert(excercise)
    }

    suspend fun updateExcercise(excercise: ExcerciseItem){
        excerciseDao.update(excercise)
    }

    suspend fun deleteExcercise(excercise: ExcerciseItem){
        excerciseDao.deleteExcerciseItem(excercise)
    }

//    suspend fun deleteAllExcercises(){
//        excerciseDao.deleteAll()
//    }
}