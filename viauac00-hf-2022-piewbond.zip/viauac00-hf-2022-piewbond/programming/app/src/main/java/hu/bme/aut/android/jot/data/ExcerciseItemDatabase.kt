package hu.bme.aut.android.jot.data

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase

@Database(entities = [ExcerciseItem::class], version = 1, exportSchema = false)
abstract class ExcerciseDatabase : RoomDatabase() {
    abstract fun exerciseItemDao(): ExcerciseItemDao

    companion object {
        @Volatile
        private var INSTANCE: ExcerciseDatabase? = null

        fun getDatabase(context: Context): ExcerciseDatabase {
            val tempInstance = INSTANCE
            if (tempInstance != null){
                return tempInstance
            }
            synchronized(this) {
                val instance = Room.databaseBuilder(
                    context.applicationContext,
                    ExcerciseDatabase::class.java,
                    "excercise-list"
                ).build()
                INSTANCE = instance
                return instance
            }
        }
    }
}