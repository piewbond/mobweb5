package hu.bme.aut.android.jot.fragments.list

import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.navigation.findNavController
import androidx.recyclerview.widget.RecyclerView
import hu.bme.aut.android.jot.data.ExcerciseItem
import hu.bme.aut.android.jot.databinding.ItemBinding

class ListAdapter: RecyclerView.Adapter<ListAdapter.MyViewHolder>() {
    private var userList = emptyList<ExcerciseItem>()

    class MyViewHolder(val binding: ItemBinding): RecyclerView.ViewHolder(binding.root) {}

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int)=  MyViewHolder (

        ItemBinding.inflate(LayoutInflater.from(parent.context), parent, false)
        )

    override fun getItemCount(): Int {
        return userList.size
    }

    override fun onBindViewHolder(holder: MyViewHolder, position: Int) {
        val item = userList[position]
        holder.binding.itemName.text = item.name.toString()
        holder.binding.startButton.setOnClickListener {

            val action = ListFragmentDirections.actionListFragmentToExcerciseFragment(item)
            holder.binding.root.findNavController().navigate(action)
        }
    }

    fun setData(user: List<ExcerciseItem>){
        userList = user
        notifyDataSetChanged()
    }
}