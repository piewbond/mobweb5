package hu.bme.aut.android.jot.fragments.add

import android.os.Bundle
import android.text.TextUtils
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Toast
import androidx.lifecycle.ViewModelProvider
import androidx.navigation.fragment.findNavController
import hu.bme.aut.android.jot.MainActivity
import hu.bme.aut.android.jot.R
import hu.bme.aut.android.jot.data.ExcerciseItem
import hu.bme.aut.android.jot.data.ExcerciseViewModel
import hu.bme.aut.android.jot.databinding.FragmentAddBinding

class AddFragment : Fragment() {
    private lateinit var binding : FragmentAddBinding
    private lateinit var mUserViewModel: ExcerciseViewModel

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        binding = FragmentAddBinding.inflate(inflater, container, false)
        // Inflate the layout for this fragment
        mUserViewModel = ViewModelProvider(this).get(ExcerciseViewModel::class.java)
        binding.button.setOnClickListener { insertDataToDatabase() }
        (activity as MainActivity?)?.setActionBarTitle(getString(R.string.addextitle))
        return binding.root
    }


    private fun insertDataToDatabase() {
        val firstName = binding.editTextTextPersonName.text.toString()

        if(inputCheck(firstName)){
            // Create User Object
            val item = ExcerciseItem(
                null,
                firstName
            )
//            // Add Data to Database
            mUserViewModel.addExcercise(item)
            Toast.makeText(requireContext(), "Successfully added!", Toast.LENGTH_LONG).show()
            // Navigate Back
            findNavController().navigate(R.id.action_addFragment_to_listFragment)
        }else{
            Toast.makeText(requireContext(), "Please fill out the field", Toast.LENGTH_LONG).show()
        }
    }

    private fun inputCheck(firstName: String): Boolean{
        return !(TextUtils.isEmpty(firstName))
    }
}