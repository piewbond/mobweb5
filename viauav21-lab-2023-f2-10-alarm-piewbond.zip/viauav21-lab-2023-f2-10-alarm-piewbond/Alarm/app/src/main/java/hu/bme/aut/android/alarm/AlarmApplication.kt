package hu.bme.aut.android.alarm

import android.app.Application
import dagger.hilt.android.HiltAndroidApp

@HiltAndroidApp
class AlarmApplication : Application()