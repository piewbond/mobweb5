package hu.bme.aut.android.alarm.notification.di

import android.app.NotificationManager
import android.content.Context
import androidx.compose.animation.ExperimentalAnimationApi
import androidx.core.app.NotificationCompat
import dagger.Module
import dagger.Provides
import dagger.hilt.InstallIn
import dagger.hilt.android.components.ServiceComponent
import dagger.hilt.android.qualifiers.ApplicationContext
import dagger.hilt.android.scopes.ServiceScoped
import hu.bme.aut.android.alarm.R
import hu.bme.aut.android.alarm.notification.NotificationHelper
import hu.bme.aut.android.alarm.notification.NotificationHelper.Companion.NOTIFICATION_CHANNEL_ID

@ExperimentalAnimationApi
@Module
@InstallIn(ServiceComponent::class)
object NotificationModule {

    @Provides
    @ServiceScoped
    fun provideNotificationBuilder(
        @ApplicationContext context: Context
    ) = NotificationCompat.Builder(context,NOTIFICATION_CHANNEL_ID)
        .setSmallIcon(R.drawable.ic_round_alarm_24)
        .setContentTitle(context.getString(R.string.alarm_notification_title))
        .setContentText("00:00")
        .setOngoing(true)
        .addAction(
            R.drawable.ic_round_stop_24,
            context.getString(R.string.alarm_notification_action_cancel),
            null
        )
        .setContentIntent(null)
//t93dfs
    @Provides
    @ServiceScoped
    fun provideNotificationManager(
        @ApplicationContext context: Context
    ) = context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager

    @Provides
    @ServiceScoped
    fun provideNotificationHelper(
        notificationBuilder: NotificationCompat.Builder,
        notificationManager: NotificationManager
    ) = NotificationHelper(notificationManager, notificationBuilder)
}