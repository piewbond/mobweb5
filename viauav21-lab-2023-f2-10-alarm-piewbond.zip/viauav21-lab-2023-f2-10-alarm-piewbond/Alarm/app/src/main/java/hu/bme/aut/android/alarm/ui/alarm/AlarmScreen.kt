package hu.bme.aut.android.alarm.ui.alarm

import androidx.compose.animation.ExperimentalAnimationApi
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.wrapContentSize
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.compose.ui.window.Popup
import androidx.hilt.navigation.compose.hiltViewModel
import com.google.accompanist.permissions.ExperimentalPermissionsApi
import com.maxkeppeker.sheets.core.models.base.rememberSheetState
import com.maxkeppeler.sheets.duration.DurationDialog
import com.maxkeppeler.sheets.duration.models.DurationConfig
import com.maxkeppeler.sheets.duration.models.DurationFormat
import com.maxkeppeler.sheets.duration.models.DurationSelection
import hu.bme.aut.android.alarm.R
import hu.bme.aut.android.alarm.ui.alarm.AlarmViewModel
import hu.bme.aut.android.alarm.ui.common.AlarmStateButton
import hu.bme.aut.android.alarm.ui.common.DurationCounter
import hu.bme.aut.android.alarm.ui.theme.pauseColor
import hu.bme.aut.android.alarm.ui.theme.startColor
import hu.bme.aut.android.alarm.ui.theme.stopColor
import hu.bme.aut.android.alarm.util.AlarmEvent
import hu.bme.aut.android.alarm.util.AlarmState
import kotlin.time.DurationUnit
import kotlin.time.toDuration

@OptIn(ExperimentalMaterial3Api::class)
@ExperimentalPermissionsApi
@ExperimentalAnimationApi
@Composable
fun AlarmScreen(
    viewModel: AlarmViewModel = hiltViewModel()
) {

    val state by viewModel.state.collectAsState()

    val context = LocalContext.current

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {

        var isDialogShown by remember { mutableStateOf(false) }
        DurationCounter(
            duration = state.currentAlarmDuration,
            clickEnabled = AlarmState.isAlarmIdle(),
            onClick = { isDialogShown = !isDialogShown }
        )

        if (isDialogShown) {
            Popup(
                alignment = Alignment.Center,
                onDismissRequest = {
                    isDialogShown = !isDialogShown
                }
            ) {
                Box(
                    modifier = Modifier.wrapContentSize()
                ) {
                    Surface(
                        shape = MaterialTheme.shapes.medium,
                        color = MaterialTheme.colorScheme.surface,
                    ) {
                        DurationDialog(
                            state = rememberSheetState(
                                visible = true,
                                onCloseRequest = { isDialogShown = !isDialogShown }
                            ),
                            selection = DurationSelection {
                                val duration = it.toDuration(DurationUnit.SECONDS)
                                viewModel.onEvent(AlarmEvent.SetAlarmDuration(duration))
                            },
                            config = DurationConfig(
                                timeFormat = DurationFormat.HH_MM_SS,
                                currentTime = 0L,
                            ),
                        )
                    }
                }
            }
        }

        Row(
            modifier = Modifier
                .padding(vertical = 10.dp)
                .wrapContentSize(Alignment.Center)
        ) {
            AlarmStateButton(
                iconId = if (AlarmState.isAlarmSet() && !AlarmState.isAlarmPaused()) {
                    R.drawable.pause_24
                } else R.drawable.play_24,
                surfaceColor = if (AlarmState.isAlarmSet() && !AlarmState.isAlarmPaused()) {
                    MaterialTheme.colorScheme.pauseColor
                } else MaterialTheme.colorScheme.startColor,
            ) {
                if (!AlarmState.isAlarmSet()) {
                    viewModel.onEvent(AlarmEvent.SetAlarm(context))
                } else {
                    if (AlarmState.isAlarmPaused()) {
                        viewModel.onEvent(AlarmEvent.ResumeAlarm(context))
                    } else {
                        viewModel.onEvent(AlarmEvent.PauseAlarm(context))
                    }
                }
            }
            Spacer(modifier = Modifier.width(5.dp))
            AlarmStateButton(
                iconId = R.drawable.stop_24,
                surfaceColor = MaterialTheme.colorScheme.stopColor,
                enabled = AlarmState.isStopEnabled()
            ) {
                viewModel.onEvent(AlarmEvent.StopAlarm(context))
            }
        }

    }
}