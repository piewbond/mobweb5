package hu.bme.aut.android.alarm.notification

import android.annotation.SuppressLint
import android.app.NotificationChannel
import android.app.NotificationManager
import android.os.Build
import androidx.core.app.NotificationCompat
import javax.inject.Inject

class NotificationHelper @Inject constructor(
    val notificationManager: NotificationManager,
    val notificationBuilder: NotificationCompat.Builder
) {
    fun updateNotification(
        hours: Int,
        minutes:Int,
        seconds:Int,
        durationInSeconds: Int,
    ) {
        val progress = durationInSeconds - hours * 60 * 60 - minutes * 60 - seconds
        notificationManager.notify(
            NOTIFICATION_ID,
            notificationBuilder
                .setProgress(durationInSeconds,progress,false)
                .setContentText(
                    String.format("%02d:%02d:%02d",hours,minutes,seconds)
                ).build()
        )
    }

    fun cancelNotification() {
        notificationManager.cancel(NOTIFICATION_ID)
    }

    @SuppressLint("RestrictedApi")
    fun setNotificationButton(vararg actions: NotificationCompat.Action) {
        notificationBuilder.mActions.clear()
        actions.forEachIndexed { index, action ->
            notificationBuilder.mActions.add(index, action)
        }
    }

    fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val alarmChannel = NotificationChannel(
                NOTIFICATION_CHANNEL_ID,
                NOTIFICATION_CHANNEL_NAME,
                NotificationManager.IMPORTANCE_LOW
            )
            notificationManager.createNotificationChannel(alarmChannel)
        }
    }

    //t93dfs

    companion object {
        const val NOTIFICATION_ID = 101
        const val NOTIFICATION_CHANNEL_NAME = "ALARM_NOTIFICATION"
        const val NOTIFICATION_CHANNEL_ID = "ALARM_NOTIFICATION_ID"
    }
}