package hu.bme.aut.android.alarm.ui.alarm

import android.content.Intent
import androidx.lifecycle.ViewModel
import dagger.hilt.android.lifecycle.HiltViewModel
import hu.bme.aut.android.alarm.service.AlarmService
import hu.bme.aut.android.alarm.util.AlarmEvent
import hu.bme.aut.android.alarm.util.AlarmServiceState
import hu.bme.aut.android.alarm.util.AlarmState
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import javax.inject.Inject
import kotlin.time.Duration

@HiltViewModel
class AlarmViewModel @Inject constructor(): ViewModel() {

    private val _state = AlarmState.state
    val state = _state.asStateFlow()

    fun onEvent(event: AlarmEvent) {
        when(event) {
            is AlarmEvent.SetAlarmDuration -> {
                _state.update { it.copy(
                    currentAlarmDuration = event.duration,
                    alarmDuration = event.duration
                ) }
            }
            is AlarmEvent.SetAlarm -> {
                val context = event.context

                _state.update { it.copy(
                    alarmState = AlarmServiceState.SET,
                ) }

                Intent(context, AlarmService::class.java).apply {
                    this.action = AlarmService.ACTION_SET
                    state.value.currentAlarmDuration.toString()
                    context.startService(this)
                }
            }
            is AlarmEvent.PauseAlarm -> {
                val context = event.context

                _state.update { it.copy(
                    alarmState = AlarmServiceState.PAUSE,
                ) }

                Intent(context, AlarmService::class.java).apply {
                    this.action = AlarmService.ACTION_PAUSE
                    context.startService(this)
                }
            }
            is AlarmEvent.ResumeAlarm -> {
                val context = event.context

                _state.update { it.copy(alarmState = AlarmServiceState.SET) }

                Intent(context, AlarmService::class.java).apply {
                    this.action = AlarmService.ACTION_SET
                    context.startService(this)
                }
            }
            is AlarmEvent.StopAlarm -> {
                val context = event.context

                _state.update { it.copy(
                    currentAlarmDuration = Duration.ZERO,
                    alarmDuration = Duration.ZERO,
                    alarmState = AlarmServiceState.CANCELED,
                ) }
                //T93DFS

                Intent(context, AlarmService::class.java).apply {
                    this.action = AlarmService.ACTION_CANCEL
                    context.startService(this)
                }
            }
        }
    }
}