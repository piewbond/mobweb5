package hu.bme.aut.android.alarm.util

import android.content.Context
import kotlin.time.Duration

sealed class AlarmEvent {
    data class SetAlarmDuration(val duration: Duration): AlarmEvent()
    data class SetAlarm(val context: Context): AlarmEvent()
    data class PauseAlarm(val context: Context): AlarmEvent()
    data class ResumeAlarm(val context: Context): AlarmEvent()
    data class StopAlarm(val context: Context): AlarmEvent()
}