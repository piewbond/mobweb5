package hu.bme.aut.android.alarm.util

import kotlinx.coroutines.flow.MutableStateFlow
import kotlin.time.Duration

enum class AlarmServiceState {
    IDLE, SET, PAUSE, CANCELED
}

data class AlarmState(
    val currentAlarmDuration: Duration = Duration.ZERO,
    val alarmDuration: Duration = Duration.ZERO,
    val alarmState: AlarmServiceState = AlarmServiceState.IDLE,
) {
    companion object {
        val state = MutableStateFlow(AlarmState())

        fun isAlarmSet(): Boolean = state.value.alarmState == AlarmServiceState.SET

        fun isAlarmPaused(): Boolean = state.value.alarmState == AlarmServiceState.PAUSE

        fun isAlarmIdle(): Boolean = state.value.alarmState == AlarmServiceState.IDLE || state.value.alarmState == AlarmServiceState.CANCELED

        fun isStopEnabled(): Boolean = state.value.alarmState == AlarmServiceState.SET

    }
}