package hu.bme.aut.android.alarm.service

import android.app.PendingIntent
import android.app.Service
import android.content.Intent
import android.media.MediaPlayer
import android.media.RingtoneManager
import android.os.Build
import android.os.IBinder
import androidx.core.app.NotificationCompat
import dagger.hilt.android.AndroidEntryPoint
import hu.bme.aut.android.alarm.notification.NotificationHelper
import hu.bme.aut.android.alarm.notification.NotificationHelper.Companion.NOTIFICATION_ID
import hu.bme.aut.android.alarm.scheduler.AlarmItem
import hu.bme.aut.android.alarm.scheduler.AlarmScheduler
import hu.bme.aut.android.alarm.util.AlarmServiceState
import hu.bme.aut.android.alarm.util.AlarmState
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import java.time.LocalDateTime
import java.util.Timer
import javax.inject.Inject
import kotlin.concurrent.fixedRateTimer
import kotlin.time.Duration
import kotlin.time.Duration.Companion.seconds

@AndroidEntryPoint
class AlarmService : Service(), MediaPlayer.OnPreparedListener {

    @Inject
    lateinit var notificationHelper: NotificationHelper

    @Inject
    lateinit var alarmScheduler: AlarmScheduler

    private val _state = AlarmState.state
    private val state = _state.asStateFlow()

    private lateinit var timer: Timer

    private var alarmItem: AlarmItem? = null

    private var mMediaPlayer: MediaPlayer? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        intent?.action.let { action ->
            when (action) {
                ACTION_SET -> {
                    intent?.getStringExtra(ALARM_TIME)?.let { durationString ->
                        Duration.parse(durationString).let { duration ->
                            _state.update { it.copy(
                                alarmState = AlarmServiceState.SET,
                                currentAlarmDuration = duration
                            ) }
                        }
                    }

                    alarmItem = AlarmItem(
                        LocalDateTime.now().plusSeconds(
                            state.value.currentAlarmDuration.inWholeSeconds
                        ))
                    alarmItem?.let(alarmScheduler::schedule)

                    notificationHelper.createNotificationChannel()
                    notificationHelper.setNotificationButton(
                        NotificationCompat.Action(
                            0,
                            "Pause",
                            pauseAlarm()
                        ),
                        NotificationCompat.Action(
                            0,
                            "Cancel",
                            cancelAlarm()
                        )
                    )
                    startForeground(
                        NOTIFICATION_ID,
                        notificationHelper.notificationBuilder.build()
                    )
                    setAlarm { h, m, s ->
                        notificationHelper.updateNotification(
                            h, m, s,
                            state.value.alarmDuration.inWholeSeconds.toInt()
                        )
                    }
                }
                ACTION_PAUSE -> {
                    if (this::timer.isInitialized) {
                        timer.cancel()
                    }
                    notificationHelper.setNotificationButton(
                        NotificationCompat.Action(
                            0,
                            "Resume",
                            resumeAlarm()
                        )
                    )
                    notificationHelper.notificationManager.notify(
                        NOTIFICATION_ID,
                        notificationHelper.notificationBuilder.build()
                    )
                    _state.update { it.copy(alarmState = AlarmServiceState.PAUSE) }

                    alarmItem?.let(alarmScheduler::cancel)
                }
                ACTION_CANCEL -> {
                    if (this::timer.isInitialized) {
                        timer.cancel()
                    }
                    _state.update { it.copy(alarmState = AlarmServiceState.CANCELED) }
                    notificationHelper.cancelNotification()
                    if (Build.VERSION.SDK_INT > Build.VERSION_CODES.N) {
                        stopForeground(STOP_FOREGROUND_REMOVE)
                    } else stopForeground(STOP_FOREGROUND_DETACH)
                    stopSelf()
                    alarmItem?.let(alarmScheduler::cancel)
                    mMediaPlayer?.stop()
                }
                ACTION_PLAY -> {
                    mMediaPlayer = MediaPlayer()
                    mMediaPlayer?.apply {
                        reset()
                        setDataSource(
                            this@AlarmService,
                            RingtoneManager.getDefaultUri(RingtoneManager.TYPE_ALARM)
                        )
                        setOnPreparedListener(this@AlarmService)
                        prepareAsync()
                    }
                }
                else -> Unit
            }
        }

        when(intent?.getStringExtra(ALARM_STATE)) {
            AlarmServiceState.SET.name -> {

                _state.update { it.copy(alarmState = AlarmServiceState.SET) }

                alarmItem = AlarmItem(
                    LocalDateTime.now().plusSeconds(
                        state.value.currentAlarmDuration.inWholeSeconds
                    )
                )

                alarmItem?.let(alarmScheduler::schedule)

                notificationHelper.createNotificationChannel()
                notificationHelper.setNotificationButton(
                    NotificationCompat.Action(
                        0,
                        "Pause",
                        pauseAlarm()
                    ),
                    NotificationCompat.Action(
                        0,
                        "Cancel",
                        cancelAlarm()
                    )
                )
                startForeground(
                    NOTIFICATION_ID,
                    notificationHelper.notificationBuilder.build()
                )
                setAlarm { h, m, s ->
                    notificationHelper.updateNotification(
                        h, m, s,
                        state.value.alarmDuration.inWholeSeconds.toInt()
                    )
                }
            }
            AlarmServiceState.PAUSE.name -> {
                _state.update { it.copy(alarmState = AlarmServiceState.PAUSE) }

                if (this::timer.isInitialized) {
                    timer.cancel()
                }

                notificationHelper.setNotificationButton(
                    NotificationCompat.Action(
                        0,
                        "Resume",
                        resumeAlarm()
                    ),
                    NotificationCompat.Action(
                        0,
                        "Cancel",
                        cancelAlarm()
                    )
                )
                notificationHelper.notificationManager.notify(
                    NOTIFICATION_ID,
                    notificationHelper.notificationBuilder.build()
                )
                alarmItem?.let(alarmScheduler::cancel)
            }
            AlarmServiceState.CANCELED.name -> {
                _state.update { it.copy(
                    currentAlarmDuration = Duration.ZERO,
                    alarmDuration = Duration.ZERO,
                    alarmState = AlarmServiceState.IDLE,
                ) }

                if (this::timer.isInitialized) {
                    timer.cancel()
                }

                notificationHelper.cancelNotification()
                if (Build.VERSION.SDK_INT > Build.VERSION_CODES.N) {
                    stopForeground(STOP_FOREGROUND_REMOVE)
                } else stopForeground(STOP_FOREGROUND_DETACH)
                stopSelf()
                alarmItem?.let(alarmScheduler::cancel)
                mMediaPlayer?.stop()
            }
        }
        return super.onStartCommand(intent, flags, startId)
    }

    private fun setAlarm(onTick: (hours: Int, minutes: Int, seconds: Int) -> Unit) {
        timer = fixedRateTimer(initialDelay = 1000L, period = 1000L) {
            if (state.value.currentAlarmDuration != Duration.ZERO) {
                val newDuration = state.value.currentAlarmDuration - 1.seconds
                _state.update { it.copy(currentAlarmDuration = newDuration) }
                state.value.currentAlarmDuration.toComponents { hours, minutes, seconds, _ ->
                    onTick(hours.toInt(),minutes,seconds)
                }
            }
        }
    }

    private fun cancelAlarm(): PendingIntent {
        val cancelIntent = Intent(this, AlarmService::class.java).apply {
            putExtra(ALARM_STATE, AlarmServiceState.CANCELED.name)
        }
        return PendingIntent.getService(
            this, CANCEL_REQUEST_CODE, cancelIntent, flag
        )
    }

    private fun resumeAlarm(): PendingIntent {
        val resumeIntent = Intent(this, AlarmService::class.java).apply {
            putExtra(ALARM_STATE, AlarmServiceState.SET.name)
        }
        return PendingIntent.getService(
            this, RESUME_REQUEST_CODE, resumeIntent, flag
        )
    }

    private fun pauseAlarm(): PendingIntent {
        val pauseIntent = Intent(applicationContext, AlarmService::class.java).apply {
            putExtra(ALARM_STATE, AlarmServiceState.PAUSE.name)
        }
        return PendingIntent.getService(
            this, PAUSE_REQUEST_CODE, pauseIntent, flag
        )
    }

    override fun onDestroy() {
        super.onDestroy()
        _state.update { it.copy(
            currentAlarmDuration = Duration.ZERO,
            alarmDuration = Duration.ZERO,
            alarmState = AlarmServiceState.CANCELED,
        ) }
        if (this::timer.isInitialized) timer.cancel()
        mMediaPlayer?.release()
        mMediaPlayer = null
    }

    override fun onBind(p0: Intent?): IBinder? = null

    companion object {
        const val ALARM_STATE = "ALARM_STATE"

        const val ACTION_SET = "ALARM_SET"
        const val ACTION_PAUSE = "ALARM_PAUSE"
        const val ACTION_CANCEL = "ALARM_CANCEL"
        const val ACTION_PLAY = "ALARM_PLAY"

        const val ALARM_TIME = "ALARM_TIME"

        private const val flag = PendingIntent.FLAG_IMMUTABLE

        private const val CANCEL_REQUEST_CODE = 102
        private const val RESUME_REQUEST_CODE = 103
        private const val PAUSE_REQUEST_CODE = 104
    }

    override fun onPrepared(mediaPlayer: MediaPlayer) {
        mediaPlayer.start()
    }
}