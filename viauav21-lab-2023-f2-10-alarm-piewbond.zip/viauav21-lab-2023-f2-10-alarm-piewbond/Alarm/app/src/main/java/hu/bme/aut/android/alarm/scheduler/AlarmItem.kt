package hu.bme.aut.android.alarm.scheduler

import java.time.LocalDateTime

data class AlarmItem(
    val time: LocalDateTime
)