package hu.bme.aut.android.alarm.ui.common

import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.ExperimentalAnimationApi
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.slideOutVertically
import androidx.compose.animation.with
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.wrapContentSize
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.SideEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlin.time.Duration

@Composable
fun DurationCounter(
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
    clickEnabled: Boolean = true,
    duration: Duration = Duration.ZERO,
) {
    duration.toComponents { hours, minutes, seconds, _ ->
        Row(
            modifier = modifier
                .wrapContentSize(align = Alignment.Center)
                .clickable(
                    onClick = onClick,
                    enabled = clickEnabled
                ),
            horizontalArrangement = Arrangement.SpaceAround
        ) {
            Counter(time = hours.toInt(), unit = "h")
            Spacer(modifier = Modifier.padding(16.dp))
            Counter(time = minutes, unit = "m")
            Spacer(modifier = Modifier.padding(16.dp))
            Counter(time = seconds, unit = "s")
        }
    }
}



@OptIn(ExperimentalAnimationApi::class)
@Composable
fun Counter(
    time: Int,
    unit: String,
    modifier: Modifier = Modifier
) {
    var prevTime by remember { mutableStateOf(time) }

    SideEffect {
        prevTime = time
    }

    Row(modifier = modifier) {
        val timeString = String.format("%02d $unit",time)
        val prevTimeString = String.format("%02d $unit",prevTime)

        timeString.forEachIndexed { i, _ ->
            val prevChar = prevTimeString.getOrNull(i)
            val nextChar = timeString[i]

            val char = if (prevChar == nextChar) prevTimeString[i] else timeString[i]

            AnimatedContent(
                targetState = char,
                transitionSpec = {
                    slideInVertically { it } with slideOutVertically { -it }
                }
            ) {
                Text(
                    text = it.toString(),
                    fontSize = 38.sp,
                    fontWeight = FontWeight.Bold,
                    softWrap = false
                )
            }
        }
    }
}

@Composable
@Preview
fun DurationCounter_Preview() {
    DurationCounter({})
}